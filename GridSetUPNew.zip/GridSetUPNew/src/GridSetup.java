import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class GridSetup {
	

	public static void main(String[] args) throws InterruptedException, MalformedURLException {
		WebDriver wd;
            String brnm="firefox";
	 		String URL = "https://demo.opencart.com/";
	 		String Node = "http://192.168.38.118:4444/wd/hub";
	 		DesiredCapabilities cap = DesiredCapabilities.firefox();
	 		
	 		
	 		cap.setBrowserName(brnm);
	 		
	 		

	 		wd = new RemoteWebDriver(new URL(Node), cap);
	 		wd.navigate().to(URL);
	 		Thread.sleep(2000);
	 		
	 		wd.findElement(By.xpath("//span[contains(text(),'My Account')]")).click();
	 		
	 		

	 		
	 		
	 		
	 			 		//Thread.sleep(5000);
	 		//wd.quit();*/
		
	/*	String baseURL = "https://demo.opencart.com";
		//http://192.168.38.118:4444/wd/hub
       String nodeURL = "http://192.168.38.118:4444/wd/hub";
        DesiredCapabilities capability = DesiredCapabilities.firefox();
        capability.setBrowserName("firefox");
        capability.setPlatform(Platform.WIN10);
        wd = new RemoteWebDriver(new URL(nodeURL), capability);
	 		*/
		
	}

	}

